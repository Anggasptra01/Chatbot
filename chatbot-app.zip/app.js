const express = require('express');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

let chatHistory = [];

app.get('/', (req, res) => {
  res.render('index', { chatHistory });
});

app.post('/chat', async (req, res) => {
  const userInput = req.body.message;
  chatHistory.push({ sender: 'User', message: userInput });

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are a helpful assistant.' },
          ...chatHistory.map(msg => ({
            role: msg.sender === 'User' ? 'user' : 'assistant',
            content: msg.message
          }))
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const botReply = response.data.choices[0].message.content.trim();
    chatHistory.push({ sender: 'Bot', message: botReply });

  } catch (error) {
    chatHistory.push({ sender: 'Bot', message: 'Error fetching response.' });
  }

  res.redirect('/');
});

app.listen(3000, () => {
  console.log('Chatbot running on http://localhost:3000');
});